function _1(md){return(
md`# Text search input with autocomplete

A reusable autocomplete search that can be used in a real-time fashion (e.g., querying an API). It exploits [\`<datalist>\`](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/datalist), the HTML Data List element.`
)}

function _2(md){return(
md`## How to use it in your notebook

\`\`\`javascript
import { SearchForm } from "@floatingpurr/input-autocomplete"
\`\`\``
)}

function _3(md){return(
md`## Examples`
)}

function _4(md){return(
md`This search form can be used with a flat array of suggestions. Let's give it a spin:`
)}

function _wiki(SearchForm,d3){return(
SearchForm({
  placeholder: "Type-in to search...",
  description: "Searching en.wikipedia.org entities",
  suggestion: async (text) => {
    const res = await d3.json(
      `https://en.wikipedia.org/w/api.php?action=opensearch&format=json&search=${text}&namespace=0&limit=10&origin=*`
    );
    return res[1];
  }
})
)}

function _6(wiki){return(
wiki
)}

function _7(md){return(
md`But it can be also useful to explore and return data from an array of objects coming from a source, e.g.:`
)}

async function _8(d3)
{
  const res = await d3.json(
    `https://en.wikipedia.org/w/api.php?action=opensearch&format=json&search=Skywalker&namespace=0&limit=10&origin=*`
  );
  return res[1].map((d, i) => ({
    entry: d,
    url: res[3][i]
  }));
}


function _9(md){return(
md`Let's see it in action:`
)}

function _wikiObject(SearchForm,d3){return(
SearchForm({
  placeholder: "Type-in to search...",
  description: "Searching en.wikipedia.org entities with their URLs",
  format: (d) => d.entry, // what you want to search and display
  suggestion: async (text) => {
    const res = await d3.json(
      `https://en.wikipedia.org/w/api.php?action=opensearch&format=json&search=${text}&namespace=0&limit=10&origin=*`
    );
    return res[1].map((d, i) => ({
      entry: d,
      url: res[3][i]
    }));
  }
})
)}

function _11(wikiObject){return(
wikiObject
)}

function _12(md){return(
md`## Configuration

* \`suggestion\`: a function providing data for live suggestions (i.e., \`<datalist>\`). This function should accept an input text and returns an array of suggestions (default: \`() => []\`)
  
* \`placeholder\`: the default text you want to use as a placeholder (default: \`""\`)
  
* \`description\`: the label describing your input (default: \`""\`)

* \`format\`: the accessor function (default: \`(d) => d\`)

* \`namespace\`: the identifier of the SearchForm, use it if you plan to use more SearchForm(s) in the same notebook (default: \`""\`)

* \`value\`: the initial value returned. It defaults to empty string. It's formatted according to \`format\` `
)}

function _13(md){return(
md`## Implementation

The machinery works as follows:
* read the value the user has just typed-in
* use such a value to retrieve suggestions (i.e., an array of matching values)
* (*suggestions are memoized*)
* inject suggestions in the \`<datalist>\` elements
* finally, the user can return a value from the suggestion list

Heavily inspired by the example of [Chris Henrick](https://observablehq.com/@clhenrick/autocomplete-search) and by suggestions of [Fabian Iwand](https://talk.observablehq.com/t/dynamic-datalist/6404/2).`
)}

function _SearchForm(DOM,htl,d3){return(
function SearchForm({
  uid = DOM.uid("autosuggestion").id,
  placeholder = "",
  description = "",
  value = "",
  format = (d) => d,
  suggestion = () => []
} = {}) {
  const input = htl.html`<input 
        type="text"
        placeholder="${placeholder}" 
        list="${uid}"
        autocomplete="off"
        value=${format(value)}
      >`;

  const tag = htl.html`<div style="font-size: 0.85rem; font-style: italic; margin-top: 3px;">${description}</div>`;

  const datalist = htl.html`<datalist id="${uid}">`;

  const form = htl.html`<div>${input}${tag}${datalist}`;

  let results = [];

  form.value = value; // starting value
  form.onsubmit = (event) => event.preventDefault();

  form.onchange = (event) => {
    const value = event.target.value;
    form.value = results.find((d) => format(d) == value) || "";
    input.blur(); // removes keyboard focus from the element upon submission
    form.dispatchEvent(new CustomEvent("input"));
  };

  // "cache"
  const options = new Map();

  const getOption = async (text) =>
    options.get(text) ||
    (text ? options.set(text, await suggestion(text)) : options.set(text, []),
    options.get(text));

  input.oninput = async (event) => {
    let value = event.target.value;

    results = await getOption(value);

    d3.select(`#${uid}`)
      .selectAll("option")
      .data(results)
      .join("option")
      .attr("value", format);
  };

  return form;
}
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer()).define(["md"], _3);
  main.variable(observer()).define(["md"], _4);
  main.variable(observer("viewof wiki")).define("viewof wiki", ["SearchForm","d3"], _wiki);
  main.variable(observer("wiki")).define("wiki", ["Generators", "viewof wiki"], (G, _) => G.input(_));
  main.variable(observer()).define(["wiki"], _6);
  main.variable(observer()).define(["md"], _7);
  main.variable(observer()).define(["d3"], _8);
  main.variable(observer()).define(["md"], _9);
  main.variable(observer("viewof wikiObject")).define("viewof wikiObject", ["SearchForm","d3"], _wikiObject);
  main.variable(observer("wikiObject")).define("wikiObject", ["Generators", "viewof wikiObject"], (G, _) => G.input(_));
  main.variable(observer()).define(["wikiObject"], _11);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer()).define(["md"], _13);
  main.variable(observer("SearchForm")).define("SearchForm", ["DOM","htl","d3"], _SearchForm);
  return main;
}
